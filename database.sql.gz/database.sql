-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Počítač: 127.0.0.1
-- Vygenerováno: Ned 16. úno 2014, 05:53
-- Verze serveru: 5.5.34
-- Verze PHP: 5.4.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databáze: `kts3_clean`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `kts_categories`
--

CREATE TABLE IF NOT EXISTS `kts_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text COLLATE utf8_czech_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci AUTO_INCREMENT=2 ;

--
-- Vypisuji data pro tabulku `kts_categories`
--

INSERT INTO `kts_categories` (`id`, `title`) VALUES
(1, 'Obecné');

-- --------------------------------------------------------

--
-- Struktura tabulky `kts_config`
--

CREATE TABLE IF NOT EXISTS `kts_config` (
  `name` varchar(50) COLLATE utf8_czech_ci NOT NULL,
  `value` varchar(1000) COLLATE utf8_czech_ci NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `kts_config`
--

INSERT INTO `kts_config` (`name`, `value`) VALUES
('title', 'KTS 3.0'),
('mainTopicID', '1'),
('keywords', 'kts,KRtek''s Topic System,RS,CMS,open source,free,php'),
('description', 'KTS 3.0'),
('template', 'kts'),
('version', '3.0.21');

-- --------------------------------------------------------

--
-- Struktura tabulky `kts_topics`
--

CREATE TABLE IF NOT EXISTS `kts_topics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categ` int(11) NOT NULL,
  `title` text COLLATE utf8_czech_ci NOT NULL,
  `value` text COLLATE utf8_czech_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci AUTO_INCREMENT=4 ;

--
-- Vypisuji data pro tabulku `kts_topics`
--

INSERT INTO `kts_topics` (`id`, `categ`, `title`, `value`, `date`) VALUES
(1, 1, 'KTS 3.0 Vás vítá!', 'KTS 3.0 Instalace\r\n-----------------\r\n1. zkopírovat obsah složky www na server.\r\n2. nastavit chmod 0777 pro složky /attachment, /gallery_data, /images/upload\r\n3. nastavit v .config.php přístupová práva pro MySQL.\r\n4. v .htaccess nastavit RewriteBase a ErrorDocument.\r\n5. v /admin/.htaccess nastavit RewriteBase\r\n6. v /admin/.htpasswd smazat default účet a nahradit svými.\r\n7. nahrát do MySQL databáze přiložený sql balík.\r\n\r\nAdministrace je typicky přístupná z {root}/admin (username: default, password: aaaaaa)\r\n\r\n\r\n\r\nKTS 3.0 - KRtek''s Topic System zveřejněn pod licencemi\r\n - GNU GPL v.3\r\n - Creative Commons BY SA 4.0\r\n\r\nOndřej Kotas, KRtkovo.eu 2014', '2014-01-01 00:00:00');

-- --------------------------------------------------------

--
-- Struktura tabulky `kts_users`
--

CREATE TABLE IF NOT EXISTS `kts_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8_czech_ci NOT NULL,
  `password` text COLLATE utf8_czech_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
